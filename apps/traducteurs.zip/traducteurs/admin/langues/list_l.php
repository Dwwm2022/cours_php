<?php
require_once('../../connect.php');
if ($base) {
    //requete
    $sql = "SELECT * FROM langues";
    //Exécution
    $res = mysqli_query($base, $sql);
}

?>
<?php require_once('../../partials/header.php'); ?>
<h1>La liste des langues</h1>
<table class="table table-striped">
    <thead class="thead-primary">
        <tr>
            <th>Id</th>
            <th>Libellé</th>
            <th>Drapeau</th>
            <th>Créé le</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        
        <tr>
            <td>1</td>
            <td>Français</td>
            <td>fr.png</td>
            <td>2022/05/12</td>
            <td>Edit</td>
        </tr>
    </tbody>
</table>
<?php require_once('../../partials/footer.php'); ?>